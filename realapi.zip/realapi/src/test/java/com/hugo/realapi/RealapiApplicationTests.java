package com.hugo.realapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
