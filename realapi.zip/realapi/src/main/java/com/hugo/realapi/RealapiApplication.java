package com.hugo.realapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealapiApplication.class, args);
	}

}
